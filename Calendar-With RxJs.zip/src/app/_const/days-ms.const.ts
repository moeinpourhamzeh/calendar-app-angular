export const DAY_MS = 60 * 60 * 24 * 1000
